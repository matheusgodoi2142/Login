document.getElementById('btn-login').addEventListener('click', function() {
    // Fazer a requisição para o arquivo PHP
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'login.php', true);
    xhr.onload = function() {
        if (xhr.status === 200) {
            // Resposta bem-sucedida
            console.log(xhr.responseText);
        } else {
            // Tratar o erro, se necessário
            console.error('Erro ao chamar a função PHP');
        }
    };
    xhr.send();
});